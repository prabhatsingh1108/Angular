import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
//  styleUrls: ['./app.component.css']
  styles: [`h3{
  color: cornflowerblue;
}`]
})
export class AppComponent {
 // title = 'smb-api-portal';
}
