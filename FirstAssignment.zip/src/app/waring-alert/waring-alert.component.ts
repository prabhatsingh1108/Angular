import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-waring-alert',
  templateUrl: './waring-alert.component.html',
  styleUrls: ['./waring-alert.component.css']
})
export class WaringAlertComponent {

}
